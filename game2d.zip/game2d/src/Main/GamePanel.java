package Main;

import Blocks.BlockManager;
import Bomb.BubbleBomb;
import Entity.Player;
import Item.SuperItem;

import java.awt.*;
import javax.swing.*;

public class GamePanel extends JPanel implements Runnable {
    //Screen settings
    final int originalTileSize = 16; // 16x16 tile
    final int scale = 3;
    public final int tileSize = originalTileSize * scale; // 48x48 tile
    public final int maxScreenCol = 16; // 16 tiles horizontally
    public final int maxScreenRow = 12; // 12 tiles vertically
    public final int screenWidth = tileSize * maxScreenCol; // 768 pixels
    public final int screenHeight = tileSize * maxScreenRow; // 576 pixels
    KeyHandler key = new KeyHandler();
    Thread gameThread;

    public CollisionCheck collisionC = new CollisionCheck(this);

    Player player = new Player(this, key);
    double fps = 60.00;

    BlockManager blockM = new BlockManager(this);
    public SuperItem[] item = new SuperItem[10];
    public Assets assetSetter = new Assets(this);

    public boolean bombPressed = false;
    public BubbleBomb[] bombs = new BubbleBomb[10];
    public boolean exploded = false;

    Sound music = new Sound();
    Sound se = new Sound();

    // sort later
    // SYSTEM
    // SCREEN SETTINGS
    // FPS
    // OBJECT
    // ENTITY

    public GamePanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(key);
        this.setFocusable(true);
    }

    public void gameSetUp() {
        assetSetter.setItem();
        playMusic(0);
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void run() {
        double drawInterval = 1000000000 / fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0; //display FPS

        while (gameThread != null) {
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1) {
                update();
                requestFocusInWindow();
                repaint();
                delta--; // reset when delta = drawInterval
                drawCount++;
            }
            if (timer >= 1000000000) {
                System.out.println("FPS:" + drawCount);
                drawCount = 0;
                timer = 0;
            }
        }
    }

    public void update() {
        player.update();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        blockM.draw(g2d);

        for (int i = 0; i < item.length; i++) {
            if(item[i] != null) {
                item[i].draw(this, g2d);
            }
        }

        player.draw(g2d);

        if (bombs[0] != null && bombPressed) {
            bombs[0].draw(this, g2d);
        }

        if (bombs[0] != null && bombs[0].exploded) {
            bombs[0].draw(this, g2d);
            System.out.println("Boom");
        }
        g2d.dispose();
    }


    public void playMusic(int i) {
        music.setFile(i);
        music.play();
        music.loop();
    }

    public void stopMusic() {
        music.stop();
    }

    public void playSE(int i) {
        se.setFile(i);
        se.play();
    }
}
