package Main;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false); //can't resize the window
        window.setTitle("Bubble bomb");
        window.setLocationRelativeTo(null); //center of screen
        window.setVisible(true); //so we can see the window

        GamePanel gamePanel = new GamePanel();
        window.add(gamePanel);
        window.pack();

        gamePanel.gameSetUp();
        gamePanel.startGameThread();
    }
}
