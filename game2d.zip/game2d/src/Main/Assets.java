package Main;

import Bomb.BubbleBomb;
import Item.ITEM_boots;
import Item.ITEM_bubble;
import Item.ITEM_potion;

public class Assets {

    GamePanel gamePanel;

    public Assets(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    public void setItem() {
        gamePanel.item[0] = new ITEM_potion();

        gamePanel.item[1] = new ITEM_boots();

        gamePanel.item[2] = new ITEM_bubble();

    }
}
