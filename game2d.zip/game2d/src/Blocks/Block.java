package Blocks;
//represents one block

import java.awt.image.BufferedImage;

public class Block {
    public BufferedImage image;
    public boolean collision = false;
}
