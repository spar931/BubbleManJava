package Bomb;

import Main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

public class BubbleBomb {
    BufferedImage image, explosion;
    public boolean collision = true;
    public Rectangle solidArea = new Rectangle(0, 0, 48, 48);
    public int solidAreaDefaultX = 0;
    public int solidAreaDefaultY = 0;
    public int x, y;
    public ArrayList<Integer> numberOfBombs = new ArrayList<>();
    public int power = 1;
    public int timeToExplode = 0, explodeInterval = 4;
    public boolean exploded = false;


    
    public BubbleBomb() {
        numberOfBombs.add(1);
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Items/manacrystal_blank.png"));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void draw(GamePanel gamePanel, Graphics2D g2d) {
        g2d.drawImage(image, x, y, gamePanel.tileSize, gamePanel.tileSize, null);
    }

    public void explode() {
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Items/shield_blue.png"));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void placeBomb() {
        gamePanel.bombPressed = true;
        gamePanel.bombs[0] = new BubbleBomb();
        if (gamePanel.bombs[0] != null) {
            gamePanel.bombs[0].x = gamePanel.tileSize * (Math.round((float) x / gamePanel.tileSize)); // bomb should be placed in middle of tile closest to player
            gamePanel.bombs[0].y = gamePanel.tileSize * (Math.round((float) y / gamePanel.tileSize));
        }
    }
}
