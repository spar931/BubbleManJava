package Entity;

import Bomb.BubbleBomb;
import Main.GamePanel;
import Main.KeyHandler;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class Player extends Entity {
    GamePanel gamePanel;
    KeyHandler key;
    int numPotions = 0; // how many potions a player has picked up
    int numBoots = 0;
    int numBubbles = 0;
    public int frameBomb = 0, intervalBomb = 7, indexAnimBomb = 0;
    public int frameExplosion = 0, intervalExplosion = 3, indexExplosion = 0;

    public Player(GamePanel gamePanel, KeyHandler key) {
        this.gamePanel = gamePanel;
        this.key = key;

        solidArea = new Rectangle(); // creating small rectangle inside character to get in between walls smoothly
        solidArea.x = 8;
        solidArea.y = 16;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 32;
        solidArea.height = 32;

        setDefaultValues();
        getPlayerImage();

    }

    public void setDefaultValues() {
        x = 50;
        y = 50;
        speed = 4;
        direction = "down";
    }

    public void getPlayerImage() {
        try {
            up1 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_up_1.png")));
            up2 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_up_2.png")));
            down1 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_down_1.png")));
            down2 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_down_2.png")));
            left1 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_left_1.png")));
            left2 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_left_2.png")));
            right1 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_right_1.png")));
            right2 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Player/boy_right_2.png")));
            bomb = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/Items/manacrystal_blank.png")));
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        if (key.up || key.down || key.left || key.right) {
            if (key.up) {
                direction = "up";
            } else if (key.left) {
                direction = "left";
            } else if (key.down) {
                direction = "down";
            } else if (key.right) {
                direction = "right";
            }
            // check block collision
            collisionOn = false;
            gamePanel.collisionC.checkBlock(this);

            // check item collision
            int itemIndex = gamePanel.collisionC.checkItem(this, true);
            pickUpItem(itemIndex);


            gamePanel.collisionC.checkBomb(this, true);

            if (!collisionOn) {
                switch (direction) {
                    case "up": y -= speed; break;
                    case "down": y += speed; break;
                    case "left": x -= speed; break;
                    case "right": x += speed; break;
                }
            }

            spriteCounter++;
            if (spriteCounter > 12) {
                if (spriteNum == 1) {
                    spriteNum = 2;
                }
                else if (spriteNum == 2) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }
        if (key.space) {
            gamePanel.bombs[0].placeBomb();
        }
        if (gamePanel.bombs[0] != null) {
            frameBomb++;
            if (frameBomb == intervalBomb) {
                frameBomb = 0;
                indexAnimBomb++;
                if (indexAnimBomb > 2) {
                    indexAnimBomb = 0;
                    gamePanel.bombs[0].timeToExplode++;
                }
                if (gamePanel.bombs[0].timeToExplode >= gamePanel.bombs[0].explodeInterval) {
                    gamePanel.bombs[0].exploded = true;
                }
            }
            if (gamePanel.bombs[0].exploded) {
                gamePanel.exploded = true;
                frameExplosion++;
                if (frameExplosion == intervalExplosion) {
                    frameExplosion = 0;
                    indexExplosion++;
                    if (indexExplosion == 4) {
                        indexExplosion = 0;
                        System.out.println("explosion");
                    }
                }
                gamePanel.bombs[0] = null;
            }
        }
    }

    public void placeBomb() {
        gamePanel.bombPressed = true;
        gamePanel.bombs[0] = new BubbleBomb();
        if (gamePanel.bombs[0] != null) {
            gamePanel.bombs[0].x = gamePanel.tileSize * (Math.round((float) x / gamePanel.tileSize)); // bomb should be placed in middle of tile closest to player
            gamePanel.bombs[0].y = gamePanel.tileSize * (Math.round((float) y / gamePanel.tileSize));
        }
    }

    public void pickUpItem(int index) {
        if (index != 9999) {
            String itemName = gamePanel.item[index].name;
            switch(itemName) { // to add bubbles, boots and other items. Will need an if statement for bubbles, as it should only work when bubbles are available
                case "Potion" :
                    gamePanel.playSE(2);
                    numPotions++;
                    gamePanel.item[index] = null; // make touched item disappear
                    System.out.println("Potions:" + numPotions);
                    break;
                case "Boots" :
                    gamePanel.playSE(3);
                    numBoots++;
                    speed += 2;
                    gamePanel.item[index] = null;
                    System.out.println("Boots:" + numBoots);
                    break;
                case "Bubble" :
                    numBubbles++;
                    gamePanel.item[index] = null;
                    System.out.println("Bubbles:" + numBubbles);
                    break;
            }
        }
    }

    public void draw(Graphics2D g2d) { // draw player
        BufferedImage image = null;
        switch(direction) {
            case "up":
                if (spriteNum == 1) {
                    image = up1;
                }
                if (spriteNum == 2) {
                    image = up2;
                }
                break;
            case "down":
                if (spriteNum == 1) {
                    image = down1;
                }
                if (spriteNum == 2) {
                    image = down2;
                }
                break;
            case "left":
                if (spriteNum == 1) {
                    image = left1;
                }
                if (spriteNum == 2) {
                    image = left2;
                }
                break;
            case "right":
                if (spriteNum == 1) {
                    image = right1;
                }
                if (spriteNum == 2) {
                    image = right2;
                }
                break;
        }
    g2d.drawImage(image, x, y, gamePanel.tileSize, gamePanel.tileSize, null);
    }
}
